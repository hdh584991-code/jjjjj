# 余烬（Ember）· 云端构建说明

## 为什么能云端编译

编译 mod 需要引用 `sts2.dll`，GitHub Actions 服务器上没有游戏。解决办法是用 NuGet 上的**引用程序集包**：

```
lamali.StS2.RefLib  0.111.0-beta
```

里面打包了 `sts2`、`GodotSharp`、`0Harmony` 三个程序集，**仅用于编译**，运行时游戏自己提供真身，不影响产物。版本号与游戏版本对应（0.111.0 → 0.111.0-beta）。

## 怎么用

1. 把整个 `Ember/` 目录推到 GitHub。
2. push 到 main（或手动点 Actions → Run workflow）。
3. 跑完在 Actions 页面下载 `Ember` 这个 artifact，解压得到：

```
Ember/
├── Ember.dll
└── Ember.json
```

4. 整个 `Ember/` 文件夹丢进游戏目录的 `mods/`：

```
Slay the Spire 2/
└── mods/
    └── Ember/
        ├── Ember.dll
        └── Ember.json
```

发版本时打个 tag（`git tag v0.1.0 && git push --tags`），会自动发 Release 并附上成品；普通 push 只构建不发版。

## 本地也能编译

电脑上有游戏时，可以改用真实程序集：

```powershell
dotnet build Ember.csproj -p:Sts2Dir="D:\SteamLibrary\steamapps\common\Slay the Spire 2"
```

指定了 `-p:Sts2Dir` 且路径下有 `sts2.dll`，csproj 会自动切到本地模式；不指定就走 NuGet，两台机器行为一致。

## 以后要加东西时

| 要加什么 | 改哪里 |
|---|---|
| 美术 / 场景 / 音效 | Godot 导出 `Ember.pck`，yml 里加一步 export-pack，`Ember.json` 的 `has_pck` 改 `true` |
| BaseLib（做人物必装） | csproj 加 `PackageReference`，`Ember.json` 的 `dependencies` 补上 |
| 换游戏目标版本 | 同步改 `Ember.csproj` 的 RefLib 版本和 `Ember.json` 的 `min_game_version` |

## 还没验证的部分

yml 语法、csproj XML、json 均已本地校验通过，但**没有真跑过 `dotnet build`**——当前环境没装 .NET 9。第一次推上去时留意 Actions 日志，如果 restore 报找不到包，检查 RefLib 版本号是否仍然有效。
