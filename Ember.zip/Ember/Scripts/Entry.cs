using System.Reflection;
using Godot.Bridge;
using HarmonyLib;
using MegaCrit.Sts2.Core.Logging;
using MegaCrit.Sts2.Core.Modding;

namespace Ember.Scripts;

/// <summary>
/// 模组入口。游戏扫描带 [ModInitializer] 的类型并调用其中的静态方法。
///
/// 时序坑：本方法运行在 ModelDb.Init 之前，此刻 ModelDb 为空，
/// 只能"挂号"（注册内容），不能查询。
/// </summary>
[ModInitializer(nameof(Init))]
public static class Entry
{
    /// <summary>必须与 Ember.json 的 id 完全一致。</summary>
    public const string ModId = "Ember";

    public static readonly Harmony Harmony = new($"sts2.mod.{ModId}");

    public static void Init()
    {
        try
        {
            Harmony.PatchAll(Assembly.GetExecutingAssembly());
            ScriptManagerBridge.LookupScriptsInAssembly(typeof(Entry).Assembly);

            // 人物与卡牌在这里注册，见后续提交

            Log.Info($"[{ModId}] 初始化完成");
        }
        catch (Exception ex)
        {
            Log.Error($"[{ModId}] 初始化失败: {ex}");
        }
    }
}
